"""Configurações compartilhadas por todo o projeto.

Indexação e busca PRECISAM usar o mesmo modelo de embeddings e a mesma coleção.
Por isso tudo fica centralizado aqui.
"""
import os

from dotenv import load_dotenv
from langchain_huggingface import HuggingFaceEmbeddings

load_dotenv()

PASTA_KNOWLEDGE = "knowledge"
PASTA_BANCO = "chroma_db"
NOME_COLECAO = "burnout_kb"

MODELO_EMBEDDINGS = "intfloat/multilingual-e5-base"

# Distância cosseno máxima aceita (0 = idêntico, 1 = sem relação).
# Ajustar rodando testar_busca.py.
LIMIAR = float(os.getenv("LIMIAR", "0.25"))
TOP_K = int(os.getenv("TOP_K", "3"))


class E5Embeddings(HuggingFaceEmbeddings):
    """O modelo e5 foi treinado com prefixos:
    'passage: ' nos textos da base e 'query: ' nas perguntas.
    Esta classe adiciona os prefixos automaticamente."""

    def embed_documents(self, texts):
        return super().embed_documents(["passage: " + t for t in texts])

    def embed_query(self, text):
        return super().embed_query("query: " + text)


def carregar_embeddings():
    return E5Embeddings(
        model_name=MODELO_EMBEDDINGS,
        encode_kwargs={"normalize_embeddings": True},
    )
