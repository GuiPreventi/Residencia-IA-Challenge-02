"""Etapa 3 do RAG: junta busca + LLM para responder.

    python rag.py                      -> conversa no terminal (colaborador)
    python rag.py gestor sono sobrecarga  -> orientação para o relatório do gestor

Escolha do LLM no arquivo .env:
    LLM_PROVIDER=gemini  (precisa de GOOGLE_API_KEY)
    LLM_PROVIDER=groq    (precisa de GROQ_API_KEY)
"""
import os
import sys

from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate

from buscar import buscar

# ---------------------------------------------------------------------------
# Guardião (versão simples). A lista e o texto de crise PRECISAM ser revisados
# por um profissional de saúde mental antes de qualquer uso real.
# ---------------------------------------------------------------------------
SINAIS_DE_CRISE = [
    "me matar", "suicid", "tirar minha vida", "acabar com tudo", "não quero mais viver",
    "nao quero mais viver", "quero morrer", "me machucar", "sumir para sempre",
]

TEXTO_CRISE = (
    "Sinto muito que você esteja passando por isso. Você não precisa enfrentar isso sozinho(a). "
    "Converse agora com o CVV, pelo telefone 188 (ligação gratuita, 24 horas) ou pelo chat em cvv.org.br. "
    "Em caso de emergência, ligue 192 (SAMU) ou vá ao pronto-socorro mais próximo. "
    "Se puder, chame também alguém de confiança para ficar com você."
)

SEM_CONTEXTO = (
    "Não tenho uma orientação específica sobre isso na minha base. "
    "Quer me contar um pouco mais sobre como você está se sentindo?"
)


def carregar_llm():
    provedor = os.getenv("LLM_PROVIDER", "gemini").lower()
    if provedor == "groq":
        from langchain_groq import ChatGroq
        return ChatGroq(model=os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile"), temperature=0.3)
    from langchain_google_genai import ChatGoogleGenerativeAI
    return ChatGoogleGenerativeAI(model=os.getenv("GEMINI_MODEL", "gemini-2.5-flash"), temperature=0.3)


PROMPT_COLABORADOR = ChatPromptTemplate.from_messages([
    ("system",
     "Você é um agente de apoio ao bem-estar no trabalho. Responda em português, "
     "de forma acolhedora e breve (até 5 frases).\n"
     "Regras:\n"
     "- Use APENAS as informações do CONTEXTO.\n"
     "- Não faça diagnóstico nem fale de medicamentos.\n"
     "- Sugira no máximo uma prática.\n"
     "- No final, escreva 'Fonte:' e o nome da fonte usada.\n\n"
     "CONTEXTO:\n{contexto}"),
    ("human", "{mensagem}"),
])

PROMPT_GESTOR = ChatPromptTemplate.from_messages([
    ("system",
     "Você ajuda gestores a cuidar da saúde da equipe. Com base APENAS no CONTEXTO, "
     "escreva de 3 a 5 ações práticas para os fatores indicados. Não cite pessoas, "
     "apenas a equipe. No final, liste as fontes usadas.\n\nCONTEXTO:\n{contexto}"),
    ("human", "Fatores que mais pesaram no risco desta semana: {mensagem}"),
])


def formatar_contexto(achados):
    return "\n\n".join(f"[Fonte: {a['fonte']}] {a['texto']}" for a in achados)


def tem_sinal_de_crise(mensagem: str) -> bool:
    m = mensagem.lower()
    return any(s in m for s in SINAIS_DE_CRISE)


def responder_colaborador(mensagem: str, llm=None) -> str:
    # 1. Guardião vem antes de tudo e NÃO passa pelo RAG.
    if tem_sinal_de_crise(mensagem):
        return TEXTO_CRISE
    # 2. Busca na base.
    achados = buscar(mensagem, para="colaborador")
    if not achados:
        return SEM_CONTEXTO
    # 3. LLM responde só com o contexto encontrado.
    cadeia = PROMPT_COLABORADOR | (llm or carregar_llm()) | StrOutputParser()
    return cadeia.invoke({"contexto": formatar_contexto(achados), "mensagem": mensagem})


def orientar_gestor(fatores: list[str], llm=None) -> str:
    """Recebe os fatores que a rede neural/SHAP apontou (ex.: ['sono', 'horas trabalhadas'])."""
    achados = []
    for fator in fatores:
        achados += buscar(f"equipe com {fator} elevado", para="gestor")
    if not achados:
        return "Sem orientações na base para esses fatores."
    unicos = list({a["arquivo"]: a for a in achados}.values())
    cadeia = PROMPT_GESTOR | (llm or carregar_llm()) | StrOutputParser()
    return cadeia.invoke({"contexto": formatar_contexto(unicos), "mensagem": ", ".join(fatores)})


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "gestor":
        print(orientar_gestor(sys.argv[2:] or ["sono", "horas trabalhadas"]))
    else:
        print("Converse com o agente (Ctrl+C para sair).")
        llm = carregar_llm()
        while True:
            print("\nAgente:", responder_colaborador(input("\nVocê: "), llm))
