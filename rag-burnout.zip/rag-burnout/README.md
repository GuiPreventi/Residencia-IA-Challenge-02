# RAG de bem-estar (burnout) com LangChain

## Como funciona

```
knowledge/*.md ──► indexar.py ──► chroma_db/ (banco vetorial)
                                        │
mensagem ──► Guardião ──► buscar.py ────┘──► rag.py (prompt + LLM) ──► resposta
```

| Arquivo | O que faz | Quem cuida |
|---|---|---|
| `knowledge/` | Textos da base, um assunto por arquivo, com etiquetas no topo | Pesquisa, redação, organização |
| `config.py` | Modelo de embeddings, nome do banco, limiar | Indexação + busca (combinado) |
| `indexar.py` | Lê os textos, divide em pedaços, gera vetores, salva no Chroma | Indexação |
| `buscar.py` | Encontra os textos mais parecidos com a frase, filtrando por público | Busca |
| `rag.py` | Guardião + busca + prompt + LLM (Gemini ou Groq) | Integração |
| `testes.csv` / `testar_busca.py` | Perguntas de teste e verificação de acertos | Avaliação |

## Instalação (uma vez)

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env               # Windows: copy .env.example .env
```

Abra o `.env` e cole a chave do Gemini (crie em https://aistudio.google.com/apikey).
Na primeira execução, o modelo de embeddings (~1 GB) é baixado automaticamente.

## Uso

```bash
python indexar.py                          # monta o banco (rodar sempre que mudar um texto)
python buscar.py "não consigo dormir"      # testa só a busca, sem LLM
python testar_busca.py                     # roda os testes e mostra as distâncias
python rag.py                              # conversa com o agente
python rag.py gestor sono "horas trabalhadas"   # orientação para o relatório do gestor
```

## Formato de um texto da base

```
---
para: colaborador          # colaborador | gestor
tipo: exercicio            # psicoeducacao | exercicio | sinal_alerta | faq | orientacao_gestor | fator
tema: sono                 # usar sempre a lista fechada de temas
fonte: Ministério da Saúde
link: https://www.gov.br/saude/
---
Texto curto (80 a 250 palavras), um assunto só, linguagem simples.
```

## Ajustando o limiar

`testar_busca.py` mostra a distância de cada resultado (0 = idêntico, 1 = sem relação).
Escolha um `LIMIAR` no `.env` que fique acima das distâncias dos acertos e abaixo
das perguntas fora do assunto.

## Importante

- A lista de sinais de crise e o texto de crise em `rag.py` são provisórios e
  precisam ser revisados por um profissional de saúde mental.
- Use apenas dados fictícios na demonstração: em planos gratuitos, o provedor
  pode usar o conteúdo enviado.
