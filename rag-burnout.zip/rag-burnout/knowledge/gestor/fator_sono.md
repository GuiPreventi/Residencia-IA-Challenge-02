---
para: gestor
tipo: fator
tema: sono
fonte: Ministério da Saúde
link: https://www.gov.br/saude/
---
Fator "sono" elevado: a equipe está dormindo pouco ou mal. Isso costuma estar ligado a jornadas
longas e à dificuldade de desconectar. Ações possíveis: respeitar o horário de fim do expediente,
evitar demandas urgentes à noite e não esperar respostas fora do horário.
