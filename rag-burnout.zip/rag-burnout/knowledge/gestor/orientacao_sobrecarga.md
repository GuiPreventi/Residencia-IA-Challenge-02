---
para: gestor
tipo: orientacao_gestor
tema: sobrecarga
fonte: Guia MTE – NR-1, riscos psicossociais
link: https://www.gov.br/trabalho-e-emprego/
---
Quando a equipe mostra sinais de sobrecarga: revise prazos e prioridades junto com o grupo,
distribua as demandas de forma equilibrada e evite mensagens fora do horário. Pergunte à equipe
o que mais pesa no momento, sem buscar culpados, e combine o que pode ser adiado.
