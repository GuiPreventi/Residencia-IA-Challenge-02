---
para: gestor
tipo: fator
tema: sobrecarga
fonte: Guia MTE – NR-1, riscos psicossociais
link: https://www.gov.br/trabalho-e-emprego/
---
Fator "horas trabalhadas" elevado: a equipe está estendendo a jornada com frequência.
Ações possíveis: mapear quais entregas estão causando horas extras, redistribuir tarefas,
renegociar prazos e acompanhar se a carga volta ao normal nas semanas seguintes.
