---
para: colaborador
tipo: faq
tema: privacidade
fonte: equipe do projeto
link: ""
---
Pergunta: a empresa vai ver minhas respostas?
Resposta: não. As respostas são guardadas sem o seu nome, e o relatório mostra apenas a média
da equipe, e só quando há pelo menos 5 pessoas respondendo.
