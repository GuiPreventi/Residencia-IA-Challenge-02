---
para: colaborador
tipo: exercicio
tema: sono
fonte: Ministério da Saúde
link: https://www.gov.br/saude/
---
Para dormir melhor: tente deitar e acordar no mesmo horário, inclusive no fim de semana.
Evite telas e mensagens de trabalho na última hora antes de dormir. Se a cabeça ficar presa
nas tarefas, anote num papel o que precisa fazer amanhã e deixe para resolver depois.
Café e energéticos depois do meio da tarde também atrapalham o sono.
