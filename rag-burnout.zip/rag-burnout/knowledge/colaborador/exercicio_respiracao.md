---
para: colaborador
tipo: exercicio
tema: pausas
fonte: Ministério da Saúde
link: https://www.gov.br/saude/
---
Respiração para momentos de tensão: sente-se com os pés no chão, inspire pelo nariz contando
até 4 e solte o ar devagar pela boca contando até 6. Repita por um minuto. Expirar mais devagar
do que inspirar ajuda o corpo a sair do estado de alerta. Pode ser feito entre reuniões ou antes
de uma tarefa difícil.
