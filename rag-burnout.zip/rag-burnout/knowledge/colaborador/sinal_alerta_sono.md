---
para: colaborador
tipo: sinal_alerta
tema: sono
fonte: Ministério da Saúde
link: https://www.gov.br/saude/
---
Dormir mal por várias noites seguidas, acordar já cansado ou pensar no trabalho antes de dormir
são sinais de que o corpo não está se recuperando. Se isso durar mais de duas semanas,
vale conversar com um profissional de saúde.
