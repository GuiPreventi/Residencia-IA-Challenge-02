---
para: colaborador
tipo: exercicio
tema: limites
fonte: Ministério da Saúde
link: https://www.gov.br/saude/
---
Para desligar do trabalho no fim do dia: defina um horário de encerramento e crie um pequeno
ritual de fechamento, como revisar a lista de amanhã e fechar o computador. Desative as
notificações de trabalho fora do expediente. Quando as demandas não cabem no horário,
converse com sua liderança sobre prioridades em vez de estender a jornada.
