---
para: colaborador
tipo: psicoeducacao
tema: exaustao
fonte: OMS – CID-11 (QD85)
link: https://icd.who.int/
---
O burnout é um fenômeno ligado ao trabalho, reconhecido pela Organização Mundial da Saúde.
Ele aparece quando o estresse do trabalho se acumula por muito tempo sem recuperação.
Envolve três sinais: cansaço extremo, distanciamento ou negatividade em relação ao trabalho
e a sensação de não estar rendendo. Sentir isso não é fraqueza, e existem caminhos de cuidado.
