"""Roda as perguntas de testes.csv e mostra se a busca acertou o tema.
Também imprime a distância de cada resultado, para ajudar a escolher o LIMIAR.

    python testar_busca.py
"""
import csv

from buscar import buscar
from config import LIMIAR

acertos = 0
with open("testes.csv", encoding="utf-8") as f:
    linhas = list(csv.DictReader(f))

for linha in linhas:
    # limiar=1.0 para ver tudo, inclusive o que seria descartado
    achados = buscar(linha["pergunta"], para=linha["para"], limiar=1.0)
    esperado = linha["tema_esperado"]
    primeiro = achados[0] if achados else None

    if esperado == "nenhum":
        ok = primeiro is None or primeiro["distancia"] > LIMIAR
    else:
        ok = primeiro is not None and primeiro["tema"] == esperado
    acertos += ok

    distancias = ", ".join(f"{a['tema']}={a['distancia']}" for a in achados)
    print(f"{'OK ' if ok else 'ERRO'} | {linha['pergunta'][:45]:45} | esperado: {esperado:11} | {distancias}")

print(f"\nAcertos: {acertos} de {len(linhas)}")
