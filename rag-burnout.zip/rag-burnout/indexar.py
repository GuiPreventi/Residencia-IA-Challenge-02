"""Etapa 1 do RAG: lê a pasta knowledge/, divide em pedaços e guarda no banco vetorial.

Rodar sempre que entrar ou mudar um texto:
    python indexar.py
"""
import shutil
from pathlib import Path

import yaml
from langchain_chroma import Chroma
from langchain_core.documents import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter

from config import NOME_COLECAO, PASTA_BANCO, PASTA_KNOWLEDGE, carregar_embeddings

CAMPOS_OBRIGATORIOS = {"para", "tipo", "tema", "fonte"}
VALORES_PARA = {"colaborador", "gestor"}


def ler_arquivo(caminho: Path) -> Document:
    """Separa o cabeçalho (etiquetas) do texto e devolve um Document do LangChain."""
    conteudo = caminho.read_text(encoding="utf-8")
    if not conteudo.startswith("---"):
        raise ValueError(f"{caminho}: falta o cabeçalho entre ---")
    _, cabecalho, texto = conteudo.split("---", 2)
    meta = yaml.safe_load(cabecalho) or {}

    faltando = CAMPOS_OBRIGATORIOS - meta.keys()
    if faltando:
        raise ValueError(f"{caminho}: faltam as etiquetas {faltando}")
    if meta["para"] not in VALORES_PARA:
        raise ValueError(f"{caminho}: 'para' deve ser colaborador ou gestor")

    meta = {k: str(v or "") for k, v in meta.items()}  # Chroma só aceita valores simples
    meta["arquivo"] = caminho.name
    return Document(page_content=texto.strip(), metadata=meta)


def main():
    arquivos = sorted(Path(PASTA_KNOWLEDGE).rglob("*.md"))
    documentos = [ler_arquivo(a) for a in arquivos]
    print(f"{len(documentos)} arquivos lidos")

    # Textos curtos viram 1 pedaço só; textos longos são divididos com sobreposição.
    divisor = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=150)
    pedacos = divisor.split_documents(documentos)
    print(f"{len(pedacos)} pedaços gerados")

    # Recria o banco do zero para não duplicar textos.
    shutil.rmtree(PASTA_BANCO, ignore_errors=True)
    Chroma.from_documents(
        documents=pedacos,
        embedding=carregar_embeddings(),
        collection_name=NOME_COLECAO,
        persist_directory=PASTA_BANCO,
        collection_metadata={"hnsw:space": "cosine"},
    )
    print(f"Banco salvo em {PASTA_BANCO}/")


if __name__ == "__main__":
    main()
