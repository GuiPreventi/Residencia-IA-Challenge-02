"""Etapa 2 do RAG: dada uma frase, encontra os textos mais relevantes da base.

Uso rápido:
    python buscar.py "não consigo dormir"
    python buscar.py "equipe fazendo muita hora extra" gestor
"""
import sys
from functools import lru_cache

from langchain_chroma import Chroma

from config import LIMIAR, NOME_COLECAO, PASTA_BANCO, TOP_K, carregar_embeddings


@lru_cache(maxsize=1)
def abrir_banco() -> Chroma:
    return Chroma(
        collection_name=NOME_COLECAO,
        embedding_function=carregar_embeddings(),
        persist_directory=PASTA_BANCO,
    )


def buscar(frase: str, para: str = "colaborador", k: int = TOP_K, limiar: float = LIMIAR):
    """Devolve até k textos com distância <= limiar, só do público indicado.

    Formato de saída (combinado com quem monta o prompt):
    [{"texto", "fonte", "tema", "tipo", "arquivo", "distancia"}, ...]
    Lista vazia = nada relevante na base.
    """
    resultados = abrir_banco().similarity_search_with_score(frase, k=k, filter={"para": para})
    saida = []
    for doc, distancia in resultados:
        if distancia <= limiar:
            saida.append({
                "texto": doc.page_content,
                "fonte": doc.metadata.get("fonte", ""),
                "tema": doc.metadata.get("tema", ""),
                "tipo": doc.metadata.get("tipo", ""),
                "arquivo": doc.metadata.get("arquivo", ""),
                "distancia": round(float(distancia), 3),
            })
    return saida


if __name__ == "__main__":
    frase = sys.argv[1] if len(sys.argv) > 1 else "não estou conseguindo dormir"
    para = sys.argv[2] if len(sys.argv) > 2 else "colaborador"
    achados = buscar(frase, para)
    if not achados:
        print("Nada relevante encontrado.")
    for r in achados:
        print(f"[{r['distancia']}] {r['arquivo']} ({r['tema']}) – {r['texto'][:80]}...")
